INSERT INTO customer (id, first_name, last_name) VALUES (default, 'Alan', 'Smith');
INSERT INTO mobile_numbers(customer_id,mobile_number) VALUES(1,9111111111);
INSERT INTO mobile_numbers(customer_id,mobile_number) VALUES(1,9111111115);

INSERT INTO customer (id, first_name, last_name) VALUES (default, 'Joe', 'Turing');
INSERT INTO mobile_numbers(customer_id,mobile_number) VALUES(2,9111111112);
INSERT INTO customer (id, first_name, last_name) VALUES (default, 'John', 'Smith');
INSERT INTO mobile_numbers(customer_id,mobile_number) VALUES(3,9111111113);
INSERT INTO customer (id, first_name, last_name) VALUES (default, 'Kathy', 'Sierra');
INSERT INTO mobile_numbers(customer_id,mobile_number) VALUES(4,9111111114);