package com.avisys.cim;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerInfoManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerInfoManagementApplication.class, args);
	}

}
